# gogoblesan-eps-1 url youtube: https://youtu.be/YDcmSjxYyP0 
# gogoblesan-eps-2 video konten: https://youtu.be/eZ2ZxisAxiA
